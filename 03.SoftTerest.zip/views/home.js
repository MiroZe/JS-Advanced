import {showSection} from '../src/router.js'

const homeSection = document.getElementById('home')



export function showHome (ctx) {
    ctx.showTargetSection(homeSection)
}