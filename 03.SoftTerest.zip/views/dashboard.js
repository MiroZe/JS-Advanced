import { showSection } from '../src/router.js'



const dashBoardSection = document.getElementById('dashboard-holder')
export function showDashboard(ctx) {

    ctx.showTargetSection(dashBoardSection)
}
