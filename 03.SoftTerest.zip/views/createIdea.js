import {showSection} from '../src/router.js'


const createSection = document.getElementById('create');


export function showCreate(ctx) {
    ctx.showTargetSection(createSection)
}




