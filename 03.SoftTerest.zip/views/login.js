

const loginSection = document.getElementById('login')



export function showLogin(ctx) {

    ctx.showTargetSection(loginSection)
}
