import {showSection} from '../src/router.js'
import {post} from '../api/api.js'
import { setToLocaleStorage } from '../src/utils.js';


const registerSection = document.getElementById('register')
const registerForm = document.getElementById('register-form');
registerForm.addEventListener('submit', registerUser)
const homeSection = document.getElementById('home')

let context = null

export function showRegister(ctx) {
    context = ctx
    ctx.showTargetSection(registerSection)
}

async function registerUser(e) {
    e.preventDefault();
    const formaData = new FormData(e.target)

    const{email, password,repeatPassword } = Object.fromEntries(formaData.entries())
    try {
        if(!email || !password || !repeatPassword) {
            throw new Error ('All inputs are mandatory')
        }
        if(email.length < 3 || password.length < 3) {
            throw new Error ('The email or paswword length should be more than 3 characters')
        }
        if(password !== repeatPassword) {
            throw new Error (' Password and Repeat Password dont match')
        }
         const data = await post('/users/register',{email,password,repeatPassword})
         setToLocaleStorage(data)
         context.showTargetSection(homeSection)




    } catch (error) {
        alert(error.message)
    }

}