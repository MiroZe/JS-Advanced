


// export function getToken() {
//     const userData = JSON.parse(localStorage('userData'))
//     return userData.accessToken
// }

export function setToLocaleStorage (data) {
    localStorage.setItem('userData',JSON.stringify(data))
}