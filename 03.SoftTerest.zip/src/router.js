import { showDashboard } from '../views/dashboard.js'
import {showLogin} from '../views/login.js'
import {showRegister} from '../views/register.js'
import {showCreate} from '../views/createIdea.js'
import {showHome} from '../views/home.js'

const main = document.getElementById('main')
const navBar = document.getElementById('navigation');


const links = {
         '/' : showHome,
         '/Dashboard':showDashboard,
         '/Login' : showLogin,
         '/Create' :showCreate,
        '/Register' : showRegister,
     }


navBar.addEventListener('click',showSection)

const ctx = {
    showTargetSection
}

export function showSection(e) {
    
    e.preventDefault();
    let target = e.target
    console.log(target.tagName)
    if(target.tagName === 'IMG') {
        target = e.target.parentElement
    }
    
    if(target.tagName === 'A') {
        const url = new URL(target.href);
        const view = links[url.pathname]
        if( typeof view == 'function') {
            view(ctx)
        }

    }
}

function showTargetSection (section) {
    main.replaceChildren(section)
}