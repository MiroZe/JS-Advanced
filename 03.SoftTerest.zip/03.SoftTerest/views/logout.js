import { get } from "../api/api.js";

const homeSection = document.getElementById('home')


export async function logout (ctx) {

    const data = await get('/users/logout')

    
    localStorage.removeItem('userData')
    ctx.updateNav();
    ctx.showTargetSection(homeSection);

}