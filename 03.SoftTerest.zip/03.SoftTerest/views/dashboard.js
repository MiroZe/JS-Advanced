import { get } from '../api/api.js'
import { showSection } from '../src/router.js'




const dashBoardSection = document.getElementById('dashboard-holder')
export async function showDashboard(ctx) {
    
    const data = await get('/data/ideas?select=_id%2Ctitle%2Cimg&sortBy=_createdOn%20desc')
    dashBoardSection.innerHTML = ''
    data.map(addIdea)
    

 ctx.showTargetSection(dashBoardSection)
}

function addIdea(data) {
    const div = document.createElement('div')
    div.classList.add("card", "overflow-hidden", "current-card", "details")
    div.style.width = '20rem'
    div.style.height = '18rem'
    if(data) {
        div.innerHTML = 
        `<div class="card-body">
                <p class="card-text">${data.title}</p>
            </div>
            <img class="card-image" src="${data.img}" alt="Card image cap">
            <a id = "${data._id}"class="btn" href="/Details">Details</a>
        </div>`
    } else {
        div.innerHTML = `<h1>No ideas yet! Be the first one :)</h1>`
    }
    dashBoardSection.appendChild(div)
}

