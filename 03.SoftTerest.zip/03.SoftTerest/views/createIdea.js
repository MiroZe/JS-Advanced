import { post } from '../api/api.js';
import {showSection} from '../src/router.js'
import { showDashboard } from './dashboard.js';


const createSection = document.getElementById('create');
const createForm = document.getElementById('create-form')
const dashBoardSection = document.getElementById('dashboard-holder')
createForm.addEventListener('submit',addIdea)

let context = null;

export function showCreate(ctx) {
    context = ctx
    ctx.showTargetSection(createSection)
}

async function addIdea(e) {
    e.preventDefault()
    const formdata = new FormData(createForm);

    const{title,description,imageURL} = Object.fromEntries(formdata.entries())

    try {
        if(!title || !description || !imageURL) {
            throw new Error (' All fields are mandatory')
        }
        if(title.length < 6) {
            throw new Error ('Title should be minimum 6 characters long')
        }
        if(description.length < 10) {
            throw new Error ('Description should be minimum 10 characters long')
        }
        if(imageURL.length < 5) {
            throw new Error ('Image should be minimum 5 characters long')
        }

        const result = await post('/data/ideas',{title,description,imageURL})
        showDashboard(context)
        

    } catch (error) {
        alert (error.message)
        
    }
    


}



