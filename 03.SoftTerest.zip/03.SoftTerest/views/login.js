import { post } from "../api/api.js";
import { setToLocaleStorage } from "../src/utils.js";


const homeSection = document.getElementById('home')
const loginSection = document.getElementById('login');
const loginForm = document.getElementById('login-form');
loginForm.addEventListener('submit',onLogin)


let context = null;

export function showLogin(ctx) {
    context = ctx;
    ctx.showTargetSection(loginSection)
}


async function onLogin(e) {
    e.preventDefault();

    const formData = new FormData(loginForm)
    const{email, password } = Object.fromEntries(formData.entries())

    try {
        if(!email || !password) {
            throw new Error('All input fields are mandatory')
        }

        const data = await post('/users/login',{email,password})
        e.target.reset()
        context.showTargetSection(homeSection)
        setToLocaleStorage(data)
        context.updateNav()

    } catch (error) {
        alert(error.message)
    }

    



}