import { get } from "../api/api.js";

const detailsDiv = document.getElementById('details')

const mainDiv = document.getElementById('dashboard-holder').addEventListener('click', showD)


function showD(e) {
    e.preventDefault()
    if(e.target.tagName == 'A') {
        console.log('click');
        let id = e.target.id
    }
    showDetails(id)
}



export async function showDetails(id) {

    const data = await get(`/data/ideas/: + id`)

    const img = createElement('img',null,detailsDiv,{className:'det-img',src:`${data.img}`})
    const descriptionDiv = createElement('div',null,detailsDiv,{className:'desc'})
    const h2 = createElement('h2',`${data.title}`,descriptionDiv,{className:'display-5'})
    const pInfo = createElement('p','Description:',descriptionDiv,{className:'infoType'})
    const pDescription = createElement('p',`${data.description}`,descriptionDiv,{className:'idea-description'})
    const btnDiv = createElement('div',null,detailsDiv,{className:'text-center'})
    const anchor = createElement('a','Delete',btnDiv,{className:'btn detb',href:'delete'})
    if(data._id !== id ) {
        anchor.disabled = 'true'
    }
    ctx.showTargetSection(detailsDiv)

} 


function createElement(type,content,parent,attribute) {
    const el = document.createElement(type)
    if(content) {
        el.textContent = content
    }
    if(parent) {
        parent.appendChild(el)
    }
    if(attribute) {
        Object.assign(el,attribute)
    }
    return el;
}
/*
<div id = "details" class="container home some">
        <img class="det-img" src="./images/dinner.jpg" />
        <div class="desc">
            <h2 class="display-5">Dinner Recipe</h2>
            <p class="infoType">Description:</p>
            <p class="idea-description">There are few things as comforting as heaping bowl of pasta at the end of a long
                day. With so many easy pasta recipes out there, there's something for every palate to love. That's why
                pasta
                makes such a quick, easy dinner for your family—it's likely to satisfy everyone's cravings, due to its
                versatility.</p>
        </div>
        <div class="text-center">
            <a class="btn detb" href="">Delete</a>
        </div>
    </div>
    */