import { showDashboard } from '../views/dashboard.js'
import {showLogin} from '../views/login.js'
import {showRegister} from '../views/register.js'
import {showCreate} from '../views/createIdea.js'
import {showHome} from '../views/home.js'
import { logout } from '../views/logout.js'
import { showDetails } from '../views/details.js'



const main = document.getElementById('main')
const navBar = document.getElementById('navigation');
const userViews = Array.from(document.querySelectorAll('.user'))
const guestViews = Array.from(document.querySelectorAll('.guest'))



const links = {
         '/' : showHome,
         '/Dashboard':showDashboard,
         '/Login' : showLogin,
         '/Create' :showCreate,
        '/Register' : showRegister,
        '/Logout' : logout,
        
     }


navBar.addEventListener('click',showSection)

const ctx = {
    showTargetSection,
    updateNav
}

export function showSection(e) {
    
    e.preventDefault();
    let target = e.target
    
    if(target.tagName === 'IMG') {
        target = e.target.parentElement
    }
    
    if(target.tagName === 'A') {
        const url = new URL(target.href);
        const view = links[url.pathname]
        if( typeof view == 'function') {
            
           
                view(ctx)
            }
            
        }

    }


function showTargetSection (section) {
    main.replaceChildren(section)
}

export function updateNav() {
    const user = localStorage.getItem('userData')
    if(user) {
        guestViews.forEach(v => v.style.display = 'none')
        userViews.forEach(v => v.style.display = 'block')
    } else {
        userViews.forEach(v => v.style.display = 'none')
        guestViews.forEach(v => v.style.display = 'block')
    }
}